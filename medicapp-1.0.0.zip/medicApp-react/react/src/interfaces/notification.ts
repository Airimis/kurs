export interface INotification {
  text: string;
  icon: string;
  time: string;
}
