export interface IOption {
  value: string;
  text?: string;
}
