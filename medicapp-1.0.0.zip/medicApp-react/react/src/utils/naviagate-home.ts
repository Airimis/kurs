import { history } from '../redux/store';

export function navigateHome() {
  history.push('/');
}
