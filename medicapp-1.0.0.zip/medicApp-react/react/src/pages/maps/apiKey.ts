export const apiKey = 'AIzaSyAbIFQ5ffgouATqs-sp8hgQf3zV4dTLzaU';
