export default [
  {
    backgroundColor: 'transparent',
    borderColor: '#7cdb86',
    pointBackgroundColor: '#7cdb86',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: '#7cdb86'
  },
  {
    backgroundColor: 'transparent',
    borderColor: '#2fa7ff',
    pointBackgroundColor: '#2fa7ff',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: '#2fa7ff'
  },
  {
    backgroundColor: 'transparent',
    borderColor: '#805aff',
    pointBackgroundColor: '#805aff',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: '#805aff'
  }
];
